﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracer.Helper
{
    public class Refractions
    {
        public static readonly float AIR = 1.00029f;
        public static readonly float GLASS = 1.49f;
        public static readonly float WATER = 1.33f;
    }
}
